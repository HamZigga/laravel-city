<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\MessageRequest;
use App\Models\Message;
use Illuminate\Support\Facades\Auth;

class MessageController extends Controller {
    public function submit(MessageRequest $req) {
        $appMessage = new Message();
        $appMessage->id_user = Auth::user()->id;
        $appMessage->subject = $req->input('category');
        $appMessage->subject = $req->input('subject');
        $appMessage->message = $req->input('message');
        $appMessage->message = $req->input('image');


        $appMessage->message = 1;

        $appMessage->save();

        return redirect()->route('profile-page')->with('success', "Сообщение было добавлено");
    }

    public function allData() {
        $appMessage = new Message();
        return view('messageData', ['date' => $appMessage->orderBy('updated-at', 'desc')->where('id_user', Auth::user()->id)->get()]);
    }

    public function allDataAdmin() {
        $appMessage = new Message();
        return view('messageDataAdmin', ['date' => $appMessage->orderBy('updated-at', 'desc')->get()]);
    }

    public function updateMessage($id){
        $appMessage = new Message();
        return view('messageUpdate', ['date' => $appMessage->find($id)]);
    }

    public function deleteMessage($id){
        $appMessage = new Message();
        $appMessage->find($id)->delete();
        return redirect()->route('messageData', $id)->with('success', "Сообщение было Удалено");
    }

    public function updateMessageSubmit($id, MessageRequest $req) {
        $appMessage = new Message();
        $appMessage = $appMessage->find($id);
        $appMessage->subject = $req->input('subject');
        $appMessage->message = $req->input('message');

        $appMessage->save();

        return redirect()->route('messageData', $id)->with('success', "Сообщение было обновлено");
    }
}
