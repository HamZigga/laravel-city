@extends ('layouts.app')

@section('title')
    Главная страница
@endsection

@section('content')
    <h1>Главная страница</h1>
    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quaerat architecto omnis vel, iusto quisquam cum fuga aut quis veritatis enim laborum temporibus blanditiis dignissimos quam possimus odio nobis optio atque.
    Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quaerat architecto omnis vel, iusto quisquam cum fuga aut quis veritatis enim laborum temporibus blanditiis dignissimos quam possimus odio nobis optio atque.
    Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quaerat architecto omnis vel, iusto quisquam cum fuga aut quis veritatis enim laborum temporibus blanditiis dignissimos quam possimus odio nobis optio atque.</p>
@endsection
