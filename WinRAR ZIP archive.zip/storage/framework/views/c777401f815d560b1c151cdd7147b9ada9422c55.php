

<?php $__env->startSection('title'); ?>
    Добавление альбома
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Добавление альбома</h1>
    <a class="btn btn-primary" style="margin-bottom: 20px;" href="<?php echo e(route('albumFind')); ?>">Предзаполнение полей</a>
    <?php if(isset($date)): ?> 
        <img src="<?php echo e($date->img); ?>" alt="album preview" style="width:120px; height:120px;">

        <form action="<?php echo e(route('albumCreate-submit')); ?>" method="POST">
            <?php echo csrf_field(); ?> 
            
            <div class="form-group">
                <label for="img"></label>
                <input class="form-control" type="text" name="img" placeholder="Введите ссылку на картинку" id="img" value="<?php echo e($date->img); ?>">
            </div>
            <div class="form-group">
                <label for="artist">Введите исполнителя</label>
                <input class="form-control" type="text" name="artist" placeholder="Исполнитель" id="artist" value="<?php echo e($date->artist); ?>">
            </div>

            <div class="form-group">
                <label for="album">Введите название альбома</label>
                <input class="form-control" type="text" name="album" placeholder="Название альбома" id="album" value="<?php echo e($date->album); ?>">
            </div>
            <div class="form-group">
                <label for="info">Введите информацию об альбоме</label>
                <textarea class="form-control" rows="6" name="info" id="info" placeholder="введите информацию"><?php echo e($date->info); ?></textarea>
            </div>
            <button type="submit" class="btn btn-success">Сохранить</button>
        </form>
    <?php endif; ?>
    <?php if(!isset($date)): ?>
        <form action="<?php echo e(route('albumCreate-submit')); ?>" method="POST">
            <?php echo csrf_field(); ?> 
            
            <div class="form-group">
                <label for="img"></label>
                <input class="form-control" type="text" name="img" placeholder="Введите ссылку на картинку" id="img" value="">
            </div>
            <div class="form-group">
                <label for="artist">Введите исполнителя</label>
                <input class="form-control" type="text" name="artist" placeholder="Исполнитель" id="artist" value="">
            </div>

            <div class="form-group">
                <label for="album">Введите название альбома</label>
                <input class="form-control" type="text" name="album" placeholder="Название альбома" id="album" value="">
            </div>
            <div class="form-group">
                <label for="info">Введите информацию об альбоме</label>
                <textarea class="form-control" rows="6" name="info" id="info" placeholder="введите информацию"></textarea>
            </div>
            <button type="submit" class="btn btn-success">Сохранить</button>
        </form>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\localhost\albummusicapp\resources\views/albumCreate.blade.php ENDPATH**/ ?>