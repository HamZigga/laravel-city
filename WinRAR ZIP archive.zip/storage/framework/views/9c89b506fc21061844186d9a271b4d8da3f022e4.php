

<?php $__env->startSection('title'); ?>
    Редактирование альбома
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Редактирование альбома</h1>

    
    <img src="<?php echo e($date->img); ?>" alt="album preview" style="width:120px; height:120px;">
    <form action="<?php echo e(route('specificAlbum-update-submit', $date->id)); ?>" method="POST">
        <?php echo csrf_field(); ?> 
    
        <div class="form-group">
            <label for="img">Введите ссылку на изображение</label>
            <input class="form-control" type="text" name="img" placeholder="Ссылка на изображение" id="img" value="<?php echo e($date->img); ?>">
        </div>
        <div class="form-group">
            <label for="artist">Введите исполнителя</label>
            <input class="form-control" type="text" name="artist" placeholder="Исполнитель" id="artist" value="<?php echo e($date->artist); ?>">
        </div>

        <div class="form-group">
            <label for="album">Введите название альбома</label>
            <input class="form-control" type="text" name="album" placeholder="Название альбома" id="album" value="<?php echo e($date->album); ?>">
        </div>
        <div class="form-group">
            <label for="info">Введите информацию об альбоме</label>
            <textarea class="form-control" rows="6" name="info" id="info" placeholder="введите информацию"><?php echo e($date->info); ?></textarea>
        </div>
        <button type="submit" class="btn btn-success">Сохранить</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\localhost\albummusicapp\resources\views/albumUpdate.blade.php ENDPATH**/ ?>