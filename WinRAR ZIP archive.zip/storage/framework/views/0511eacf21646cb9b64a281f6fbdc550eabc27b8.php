

<?php $__env->startSection('title'); ?>
    Создание альбома
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Поиск доп инф</h1>
    
    <form action="<?php echo e(route('albumFind-form')); ?>" method="POST">
        <?php echo csrf_field(); ?> 

        <div class="form-group">
            <label for="artist">Введите исполнителя</label>
            <input class="form-control" type="text" name="artist" placeholder="Исполнитель" id="artist">
        </div>

        <div class="form-group">
            <label for="album">Введите название альбома</label>
            <input class="form-control" type="text" name="album" placeholder="Название альбома" id="album">
        </div>
        <button type="submit" class="btn btn-success">Найти</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\localhost\albumMusicApp\resources\views/albumFind.blade.php ENDPATH**/ ?>