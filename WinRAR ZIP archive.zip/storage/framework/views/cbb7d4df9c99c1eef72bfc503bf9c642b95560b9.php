<?php echo e($slot); ?>

<?php /**PATH C:\OpenServer\domains\localhost\albumMusicApp\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>