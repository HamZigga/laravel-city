

<?php $__env->startSection('title'); ?>
    Профиль
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Профиль</h1>
    <p><?php echo e(Auth::user()->name); ?></p>
    <p><?php echo e(Auth::user()->email); ?></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\localhost\laravelCity\resources\views/profile.blade.php ENDPATH**/ ?>