

<?php $__env->startSection('title'); ?>
    Описание альбома
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <h1><?php echo e($date->artist); ?> — <?php echo e($date->album); ?></h1>
        <div class="row">
            <img src="<?php echo e($date->img); ?>" alt="preview" class="col-3 h-100">
            <div class="col-8" >   
                
                <p><?php echo e($date->info); ?></p>
                <p><small><?php echo e($date->created_at); ?></small></p>
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('specificAlbum-update', $date->id)); ?>"><button class="btn btn-primary">Редактировать</button></a>
                    <a href="<?php echo e(route('specificAlbum-delete', $date->id)); ?>"><button class="btn btn-danger">Удалить</button></a>
                <?php endif; ?>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\localhost\albumMusicApp\resources\views/albumSpecific.blade.php ENDPATH**/ ?>